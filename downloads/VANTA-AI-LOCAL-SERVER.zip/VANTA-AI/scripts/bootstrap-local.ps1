$ErrorActionPreference = 'Stop';
try {
  if ($PSScriptRoot) { $vantaRoot = Split-Path -Parent $PSScriptRoot; } else { $vantaRoot = $env:VANTA_APP_DIR; };
  Set-Location -LiteralPath $vantaRoot;
  $vantaNode = $null;
  $vantaCommand = Get-Command node -ErrorAction SilentlyContinue;
  if ($vantaCommand) {
    $vantaVersion = & $vantaCommand.Source --version;
    $vantaArch = & $vantaCommand.Source -p 'process.arch';
    if (([version]($vantaVersion.TrimStart('v')) -ge [version]'24.5.0') -and ($vantaArch -eq 'x64')) { $vantaNode = $vantaCommand.Source; };
  };
  if (-not $vantaNode) {
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'VANTA needs 64-bit Windows.'; };
    $vantaCache = Join-Path $vantaRoot '.vanta-runtime\node-downloads';
    New-Item -ItemType Directory -Force -Path $vantaCache | Out-Null;
    $vantaArchive = Join-Path $vantaCache 'node-v24.22.0-win-x64.zip';
    $vantaExpected = 'f9683a19877e12a9b167305c8db71040d812876359de21f0d2e97c3f321f80c3';
    $vantaValid = (Test-Path -LiteralPath $vantaArchive) -and ((Get-FileHash -Algorithm SHA256 -LiteralPath $vantaArchive).Hash.ToLowerInvariant() -eq $vantaExpected);
    if (-not $vantaValid) {
      Write-Host 'Downloading verified portable Node.js 24.22.0...';
      $vantaPartial = $vantaArchive + '.partial';
      Invoke-WebRequest -UseBasicParsing -Uri 'https://nodejs.org/dist/v24.22.0/node-v24.22.0-win-x64.zip' -OutFile $vantaPartial;
      if ((Get-FileHash -Algorithm SHA256 -LiteralPath $vantaPartial).Hash.ToLowerInvariant() -ne $vantaExpected) { Remove-Item -LiteralPath $vantaPartial -Force; throw 'Node.js checksum verification failed. Startup stopped.'; };
      Move-Item -LiteralPath $vantaPartial -Destination $vantaArchive -Force;
    };
    $vantaRuntime = Join-Path $vantaRoot '.vanta-runtime';
    $vantaFolder = Join-Path $vantaRuntime 'node-v24.22.0-win-x64';
    if (Test-Path -LiteralPath $vantaFolder) { Remove-Item -LiteralPath $vantaFolder -Recurse -Force; };
    Expand-Archive -LiteralPath $vantaArchive -DestinationPath $vantaRuntime -Force;
    $vantaNode = Join-Path $vantaFolder 'node.exe';
  };
  & $vantaNode --use-env-proxy --use-system-ca (Join-Path $vantaRoot 'scripts\start-local.mjs');
  exit $LASTEXITCODE;
} catch {
  Write-Host ('VANTA could not start: ' + $_.Exception.Message) -ForegroundColor Red;
  exit 1;
};
